package academy.devDojo.maratonajava.introducao;

public class OlaDevDojo {
    public static void main(String[] args) {
        System.out.println("José ");
    }
}
