package academy.devDojo.maratonajava.javacore.Minterfaces.dominio;

public interface DataRemover {
    public abstract void remove();
}
