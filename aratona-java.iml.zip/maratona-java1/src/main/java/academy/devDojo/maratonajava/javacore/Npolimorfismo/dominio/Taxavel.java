package academy.devDojo.maratonajava.javacore.Npolimorfismo.dominio;

public interface Taxavel {
    public double calcularImposto();
}
