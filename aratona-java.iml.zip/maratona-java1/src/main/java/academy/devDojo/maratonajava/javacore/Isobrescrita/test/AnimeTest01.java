package academy.devDojo.maratonajava.javacore.Isobrescrita.test;

import academy.devDojo.maratonajava.javacore.Isobrescrita.dominio.Anime;

public class AnimeTest01 {
    public static void main(String[] args) {
        Anime anime = new Anime("Dr. Stone");
        System.out.println(anime);

    }
}
