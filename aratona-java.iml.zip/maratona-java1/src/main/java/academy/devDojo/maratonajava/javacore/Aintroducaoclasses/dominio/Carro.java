package academy.devDojo.maratonajava.javacore.Aintroducaoclasses.dominio;

public class Carro {
   public String nome;
   public String modelo;
    public int ano;


}
