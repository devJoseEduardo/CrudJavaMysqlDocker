package academy.devDojo.maratonajava.javacore.Oexception.runtime.test;

public class RuntimeExeptionTest01 {
    public static void main(String[] args) {
        //checked e Unchecked
        int[] nums = {1,2};
        System.out.println(nums[2]);
    }
}
