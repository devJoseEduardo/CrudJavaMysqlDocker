package academy.devDojo.maratonajava.javacore.Lclassesabstratas.dominio;

public abstract class Pessoa {
    public abstract void  imprime();

}
