package academy.devDojo.maratonajava.javacore.Gassociacao.test;

import academy.devDojo.maratonajava.javacore.Gassociacao.dominio.Aluno;
import academy.devDojo.maratonajava.javacore.Gassociacao.dominio.Seminario;

public class SeminarioTest02 {
    public static void main(String[] args) {
        Aluno aluno = new Aluno("Caio Castro",22);
        Aluno aluno2 = new Aluno("Cabelinho",43);
        Aluno aluno3 = new Aluno("Felipe neto",11);
                Aluno[] alunos= {aluno,aluno2,aluno3};
     //   Seminario seminario = new Seminario("Bela e o urso",alunos);
        //seminario.imprime();

    }
}
