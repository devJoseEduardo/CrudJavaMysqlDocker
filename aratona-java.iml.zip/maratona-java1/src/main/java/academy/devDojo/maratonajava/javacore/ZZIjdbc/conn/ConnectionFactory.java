package academy.devDojo.maratonajava.javacore.ZZIjdbc.conn;

import java.sql.Connection;

public class ConnectionFactory {
    //java.sql = Conection, Statemente, ResultSet, DriverManager

}
