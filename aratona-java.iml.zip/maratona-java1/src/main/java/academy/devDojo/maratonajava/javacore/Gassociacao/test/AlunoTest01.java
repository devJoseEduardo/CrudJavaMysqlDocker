package academy.devDojo.maratonajava.javacore.Gassociacao.test;

import academy.devDojo.maratonajava.javacore.Gassociacao.dominio.Aluno;
import academy.devDojo.maratonajava.javacore.Gassociacao.dominio.Seminario;

public class AlunoTest01 {
    public static void main(String[] args) {
//        Seminario seminario = new Seminario("O pateta preto");
       // aluno.setSeminario(seminario);
       //aluno.imprime();
    }
}
