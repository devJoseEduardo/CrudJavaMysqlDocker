package academy.devDojo.maratonajava.javacore.JmodificadorFInal.dominio;

public class Ferrari extends Carro {


}
