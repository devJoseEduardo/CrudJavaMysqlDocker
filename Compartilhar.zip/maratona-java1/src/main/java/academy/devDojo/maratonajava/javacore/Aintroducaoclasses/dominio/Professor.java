package academy.devDojo.maratonajava.javacore.Aintroducaoclasses.dominio;

public class Professor {
    public String nome;
    public int idade;
    public char sexo;
}
