package academy.devDojo.maratonajava.javacore.Oexception.error.test;

public class StackOverFlowTest01 {
    public static void main(String[] args) {

    }

    public static void recursividade() {
        recursividade();
    }
}
