package academy.devDojo.maratonajava.javacore.Npolimorfismo.repositorio;

public interface Repositorio {
    public abstract void salvar();
}
