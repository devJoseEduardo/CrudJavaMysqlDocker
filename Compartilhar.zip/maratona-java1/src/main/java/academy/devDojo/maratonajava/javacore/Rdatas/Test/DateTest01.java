package academy.devDojo.maratonajava.javacore.Rdatas.Test;

import java.util.Date;

public class DateTest01 {
    public static void main(String[] args) {
        Date date = new Date();
    }
}
