package academy.devDojo.maratonajava.javacore.Aintroducaoclasses.dominio;

public class Estudante {
    public String nome = "Zoro";
    public int idade;
    public char sexo;
}
