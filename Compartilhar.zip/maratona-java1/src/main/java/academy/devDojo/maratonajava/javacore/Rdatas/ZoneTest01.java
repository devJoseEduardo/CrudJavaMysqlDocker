package academy.devDojo.maratonajava.javacore.Rdatas;

import java.time.ZoneId;
import java.util.Map;

public class ZoneTest01 {
    public static void main(String[] args) {
        Map<String, String> shortIds = ZoneId.SHORT_IDS;
    }
}
