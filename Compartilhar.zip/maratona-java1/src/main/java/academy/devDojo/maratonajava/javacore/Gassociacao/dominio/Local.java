package academy.devDojo.maratonajava.javacore.Gassociacao.dominio;

public class Local {
    private String endereço;
    public Local(String endereço) {
        this.endereço = endereço;

    }

    public String getEndereço() {
        return endereço;
    }

    public void setEndereço(String endereço) {
        this.endereço = endereço;
    }


}
